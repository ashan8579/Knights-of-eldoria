import random
from grid import Grid
from entities.treasure import Treasure
from entities.hunter import Hunter
from entities.hideout import Hideout
from entities.knight import Knight
from visualizer import EldoriaVisualizer

class SimulationManager:
    def __init__(self, width=20, height=20):
        self.grid = Grid(width, height)
        self.hunters = []
        self.knights = []
        self.hideouts = []
        self.treasures = []
        self.collected_treasures = 0
        self.hunter_scores = {}

    def setup(self):
        print("Starting Eldoria Simulation")
        print(f"Initializing {self.grid.width}x{self.grid.height} grid...")

        for _ in range(3):
            h = Hideout()
            self.hideouts.append(h)
            self.grid.place_entity(random.randint(0, 19), random.randint(0, 19), h)
        print("Placing 3 hideouts...")

        for i in range(5):
            h = Hunter(f"Hunter#{i}", random.choice(["navigation", "stealth", "endurance"]))
            self.hunters.append(h)
            self.hunter_scores[h.name] = 0
            hideout = random.choice(self.hideouts)
            self.grid.place_entity(hideout.x, hideout.y, h)
            hideout.hunters.append(h)
        print("Spawning 5 treasure hunters...")

        for _ in range(40):
            t = Treasure(random.choice(["bronze", "silver", "gold"]))
            self.grid.place_entity(random.randint(0, 19), random.randint(0, 19), t)
            self.treasures.append(t)
        print("Generating 40 treasure pieces...")

        for _ in range(3):
            k = Knight()
            self.knights.append(k)
            self.grid.place_entity(random.randint(0, 19), random.randint(0, 19), k)
        print("Deploying 3 knights...\n")

        print("=== Simulation Running ===")

    def run_step(self, step):
        for hunter in self.hunters:
            if hunter.stamina > 0:
                if hunter.stamina <= 6:
                    hideouts_nearby = [h for h in self.hideouts if abs(h.x - hunter.x) <= 1 and abs(h.y - hunter.y) <= 1]
                    if hideouts_nearby:
                        hunter.rest()
                        continue
                hunter.move(self.grid)
                treasures_found = hunter.scan(self.grid)
                if not hunter.carrying:
                    hunter.pick_up(self.grid)
                else:
                    for hideout in self.hideouts:
                        if abs(hideout.x - hunter.x) <= 1 and abs(hideout.y - hunter.y) <= 1:
                            hideout.store(hunter)
                            print(f"{hunter.name} stored treasure at hideout.")
                            self.collected_treasures += 1
                            self.hunter_scores[hunter.name] += 1

        for knight in self.knights:
            if knight.energy <= 20:
                knight.energy += 10
                continue
            target = knight.detect_hunters(self.grid)
            if target:
                knight.chase(self.grid, target)

        for h in self.hideouts:
            h.rest_hunters()
            h.share_knowledge()

        for t in self.treasures[:]:
            if not t.degrade():
                self.grid.remove_entity(t)
                self.treasures.remove(t)

        for hideout in self.hideouts:
            skills = set(h.skill for h in hideout.hunters)
            if len(hideout.hunters) < 5 and len(skills) >= 2 and random.random() < 0.2:
                new_skill = random.choice(list(skills))
                new_hunter = Hunter(f"Hunter#{len(self.hunters)}", new_skill)
                self.hunters.append(new_hunter)
                self.hunter_scores[new_hunter.name] = 0
                self.grid.place_entity(hideout.x, hideout.y, new_hunter)
                hideout.hunters.append(new_hunter)

    def is_finished(self):
        return len(self.treasures) == 0 or all(h.stamina <= 0 for h in self.hunters)

    def run(self):
        self.setup()
        visualizer = EldoriaVisualizer(self.grid)
        step = 1
        max_steps = 1000

        while not self.is_finished() and step <= max_steps:
            print(f"--- Simulation Step {step} ---")
            self.run_step(step)
            visualizer.update()
            step += 1

        self.print_summary(step - 1)
        visualizer.window.mainloop()

    def print_summary(self, steps_run):
        print("\n=== Simulation Complete ===")
        print(f"Runtime: {steps_run} steps")
        remaining = len(self.treasures)
        total = self.collected_treasures + remaining
        percent = (self.collected_treasures / total) * 100 if total else 0

        active = sum(1 for h in self.hunters if h.stamina > 0)
        lost = len(self.hunters) - active
        resting_knights = sum(1 for k in self.knights if k.energy <= 20)

        print("Results:")
        print(f"- Treasure collected: {self.collected_treasures} ({percent:.1f}%)")
        print(f"- Treasure remaining: {remaining}")
        print(f"- Active hunters: {active}")
        print(f"- Hunters lost: {lost}")
        print(f"- Knights active: {len(self.knights)}")
        print(f"- Knights resting: {resting_knights}")

        sorted_scores = sorted(self.hunter_scores.items(), key=lambda x: x[1], reverse=True)
        print("\nTop hunters:")
        for i, (name, score) in enumerate(sorted_scores[:3], 1):
            skill = next(h.skill for h in self.hunters if h.name == name)
            print(f"{i}. {name} ({skill.capitalize()}): {score} treasures")