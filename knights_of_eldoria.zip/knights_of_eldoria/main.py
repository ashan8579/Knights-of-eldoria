from simulation_manager import SimulationManager

if __name__ == "__main__":
    sim = SimulationManager()
    sim.run()