class Grid:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.grid = [[[] for _ in range(width)] for _ in range(height)]

    def wrap_coords(self, x, y):
        return x % self.width, y % self.height

    def place_entity(self, x, y, entity):
        x, y = self.wrap_coords(x, y)
        entity.x = x
        entity.y = y
        self.grid[y][x].append(entity)

    def remove_entity(self, entity):
        x, y = entity.x, entity.y
        if entity in self.grid[y][x]:
            self.grid[y][x].remove(entity)

    def move_entity(self, entity, new_x, new_y):
        old_x, old_y = entity.x, entity.y
        new_x, new_y = self.wrap_coords(new_x, new_y)
        if entity in self.grid[old_y][old_x]:
            self.grid[old_y][old_x].remove(entity)
        self.grid[new_y][new_x].append(entity)
        entity.x = new_x
        entity.y = new_y

    def get_entities_at(self, x, y):
        x, y = self.wrap_coords(x, y)
        return self.grid[y][x]
