import random

class Knight:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.energy = 100.0
        self.resting = False

    def detect_hunters(self, grid):
        for dx in range(-3, 4):
            for dy in range(-3, 4):
                tx, ty = grid.wrap_coords(self.x + dx, self.y + dy)
                for entity in grid.get_entities_at(tx, ty):
                    if entity.__class__.__name__ == "Hunter" and entity.stamina > 0:
                        return entity
        return None

    def chase(self, grid, target):
        if self.energy < 20:
            self.resting = True
            return

        dx = target.x - self.x
        dy = target.y - self.y
        move_x = 1 if dx > 0 else -1 if dx < 0 else 0
        move_y = 1 if dy > 0 else -1 if dy < 0 else 0

        new_x, new_y = grid.wrap_coords(self.x + move_x, self.y + move_y)
        grid.move_entity(self, new_x, new_y)
        self.x, self.y = new_x, new_y
        self.energy -= 20.0

        if self.x == target.x and self.y == target.y:
            self.engage(target)

    def engage(self, hunter):
        outcome = random.choice(["detain", "challenge"])
        if outcome == "detain":
            hunter.stamina -= 5.0
        else:
            hunter.stamina -= 20.0
        hunter.carrying = None

    def recover(self):
        if self.resting:
            self.energy += 10
            if self.energy >= 100:
                self.resting = False
