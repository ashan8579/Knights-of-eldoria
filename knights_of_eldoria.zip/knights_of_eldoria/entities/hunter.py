import random

class Hunter:
    def __init__(self, name, skill):
        self.name = name
        self.skill = skill
        self.stamina = 100
        self.carrying = None
        self.memory = {"treasures": [], "hideouts": [], "knights": []}
        self.x = None
        self.y = None
        self.steps_without_energy = 0

    def move(self, grid):
        if self.stamina <= 0:
            self.steps_without_energy += 1
            print(f"{self.name} is exhausted! ({self.steps_without_energy} steps without energy)")
            if self.steps_without_energy >= 3:
                if self.carrying:
                    print(f"{self.name} dropped treasure due to collapse: {self.carrying.kind}")
                    grid.place_entity(self.x, self.y, self.carrying)
                    self.memory["treasures"].append(self.carrying)
                    self.carrying = None
            return

        target = None
        if self.stamina <= 6 and self.memory["hideouts"]:
            target = min(self.memory["hideouts"], key=lambda h: abs(h.x - self.x) + abs(h.y - self.y))
        elif self.memory["treasures"]:
            self.memory["treasures"] = [t for t in self.memory["treasures"] if hasattr(t, "x") and hasattr(t, "y")]
            if self.memory["treasures"]:
                target = min(self.memory["treasures"], key=lambda t: abs(t.x - self.x) + abs(t.y - self.y))

        if target:
            dx = target.x - self.x
            dy = target.y - self.y
            move_x = 1 if dx > 0 else -1 if dx < 0 else 0
            move_y = 1 if dy > 0 else -1 if dy < 0 else 0
        else:
            move_x, move_y = random.choice([(0,1), (1,0), (0,-1), (-1,0)])

        new_x, new_y = self.x + move_x, self.y + move_y
        grid.move_entity(self, new_x, new_y)
        self.x, self.y = grid.wrap_coords(new_x, new_y)
        self.stamina -= 2
        print(f"{self.name} moved to ({self.x}, {self.y}) - stamina: {self.stamina:.1f}%")

    def scan(self, grid):
        found = []
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                tx, ty = grid.wrap_coords(self.x + dx, self.y + dy)
                for obj in grid.get_entities_at(tx, ty):
                    if hasattr(obj, "value") and obj not in self.memory["treasures"]:
                        self.memory["treasures"].append(obj)
                        found.append(obj)
                    elif obj.__class__.__name__ == "Hideout" and obj not in self.memory["hideouts"]:
                        self.memory["hideouts"].append(obj)
                    elif obj.__class__.__name__ == "Knight" and obj not in self.memory["knights"]:
                        self.memory["knights"].append(obj)
        print(f"{self.name} scanned and found treasures: {[t.kind for t in found]}")
        return found

    def pick_up(self, grid):
        if self.carrying:
            return
        for obj in grid.get_entities_at(self.x, self.y):
            if hasattr(obj, "value"):
                grid.remove_entity(obj)
                self.memory["treasures"] = [t for t in self.memory["treasures"] if t != obj]
                self.carrying = obj
                print(f"{self.name} picked up {obj.kind} treasure worth {obj.value:.2f}%")
                return

    def rest(self):
        if self.stamina < 100:
            self.stamina += 1
            print(f"{self.name} is resting... stamina: {self.stamina:.1f}%")
        if self.stamina > 6:
            self.steps_without_energy = 0

    def is_exhausted(self):
        return self.stamina <= 0 and self.steps_without_energy >= 3