class Hideout:
    def __init__(self):
        self.hunters = []
        self.x = 0
        self.y = 0
        self.stored_treasures = []

    def rest_hunters(self):
        for h in self.hunters:
            if h.stamina < 100:
                h.rest()
                print(f"{h.name} is resting at hideout. Stamina: {h.stamina:.1f}%")
            if h.stamina > 0:
                h.steps_without_energy = 0

    def store(self, hunter):
        if hunter.carrying:
            print(f"{hunter.name} stored {hunter.carrying.kind} worth {hunter.carrying.value:.2f}% at hideout")
            self.stored_treasures.append(hunter.carrying)
            hunter.carrying = None

    def share_knowledge(self):
        for h1 in self.hunters:
            for h2 in self.hunters:
                if h1 != h2:
                    for category in ["treasures", "hideouts", "knights"]:
                        for item in h2.memory[category]:
                            if item not in h1.memory[category]:
                                h1.memory[category].append(item)

    def add_hunter(self, hunter):
        if len(self.hunters) < 5:
            self.hunters.append(hunter)
