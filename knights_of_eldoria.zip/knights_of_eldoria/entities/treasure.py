class Treasure:
    def __init__(self, kind):
        self.kind = kind
        self.value_map = {"bronze": 3, "silver": 7, "gold": 13}
        self.value = self.value_map[kind]
        self.x = None
        self.y = None

    def degrade(self):
        self.value -= self.value * 0.001
        return self.value > 0
