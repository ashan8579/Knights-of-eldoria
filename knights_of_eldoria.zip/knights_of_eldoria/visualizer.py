import tkinter as tk
from grid import Grid

ICONS = {
    "Treasure_bronze": "🥉",
    "Treasure_silver": "🥊",
    "Treasure_gold": "🥇",
    "Hunter": "🢍",
    "Knight": "🛡️",
    "Hideout": "🏠",
    "Empty": "⬜"
}

class EldoriaVisualizer:
    def __init__(self, grid: Grid):
        self.grid = grid
        self.cell_size = 30
        self.window = tk.Tk()
        self.window.title("Eldoria Treasure Hunt")
        self.canvas = tk.Canvas(
            self.window,
            width=self.grid.width * self.cell_size,
            height=self.grid.height * self.cell_size,
            bg="white"
        )
        self.canvas.pack()
        self.draw_grid()

    def draw_grid(self):
        self.canvas.delete("all")
        for y in range(self.grid.height):
            for x in range(self.grid.width):
                entities = self.grid.get_entities_at(x, y)
                icon = ICONS["Empty"]
                color = "white"
                
                # Draw priority: Hunter > Knight > Hideout > Treasure
                for e in entities:
                    if e.__class__.__name__ == "Hunter":
                        icon = ICONS["Hunter"]
                        color = "green" if e.stamina > 50 else "yellow" if e.stamina > 20 else "red"
                        break
                    elif e.__class__.__name__ == "Knight":
                        icon = ICONS["Knight"]
                        color = "lightblue"
                        break
                    elif e.__class__.__name__ == "Hideout":
                        icon = ICONS["Hideout"]
                        color = "gray"
                        break
                    elif e.__class__.__name__ == "Treasure":
                        icon = ICONS[f"Treasure_{e.kind}"]

                # Draw cell
                self.canvas.create_rectangle(
                    x * self.cell_size,
                    y * self.cell_size,
                    (x+1) * self.cell_size,
                    (y+1) * self.cell_size,
                    fill=color,
                    outline="black"
                )

                # Draw icon
                self.canvas.create_text(
                    x * self.cell_size + self.cell_size//2,
                    y * self.cell_size + self.cell_size//2,
                    text=icon,
                    font=("Arial", 16)
                )

                # Show carried treasure
                for e in entities:
                    if e.__class__.__name__ == "Hunter" and e.carrying:
                        self.canvas.create_text(
                            x * self.cell_size + 25,
                            y * self.cell_size + 25,
                            text="💎",
                            font=("Arial", 10)
                        )

    def update(self):
        self.draw_grid()
        self.window.update()